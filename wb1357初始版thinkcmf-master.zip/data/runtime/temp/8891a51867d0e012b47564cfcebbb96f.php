<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:53:"themes/admin_materialdashboard/admin\theme\index.html";i:1531823785;s:82:"D:\WWW\thinkcmf-master\public\themes\admin_materialdashboard\public\emptypage.html";i:1531904022;}*/ ?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="/themes/admin_materialdashboard/public/assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="/themes/admin_materialdashboard/public/assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
   
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="/themes/admin_materialdashboard/public/assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }
        .form-required {
            color: red;
        }
        .card .form-horizontal .form-group {
            margin-top: 14px;
        }
        .form-group .bmd-label-static {
          top:-20px;
        }
    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo \think\Request::instance()->module(); ?>'/*当前应用名*/
        };
    </script>
    </script>
    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>

    <script src="https://cdn.bootcss.com/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="/static/js/wind.js"></script>
    <script src="/themes/admin_materialdashboard/public/assets/js/bootstrap.min.js"></script>

    <script>
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container:'body',
                html:true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
        });

    </script>
    <?php if(APP_DEBUG): ?>
        <style>
            #think_page_trace_open {
                z-index: 9999;
            }
        </style>
    <?php endif; ?>
  
</head>

<body class="">
  <div class="content ">
    
<div class="card">
<div class="card-header card-header-primary">
    <ul class="nav nav-tabs" data-tabs="tabs">
        <li class="nav-item">
          <a class="nav-link active"  href="<?php echo url('theme/index'); ?>">所有模板</a></li>

        <li class="nav-item">
          <a class="nav-link"  href="<?php echo url('theme/install'); ?>">安装模板</a></li>
    </ul>
</div>

    <div class="row">
            <div class="col-md-12">
                  <div class="card-body">
                <form method="post" class="js-ajax-form margin-top-20">
                    <?php  $status=array("1"=>lang('DISPLAY'),"0"=>lang('HIDDEN')); ?>
                    <table class="table table-hover table-bordered table-list">
                        <thead>
                        <tr>
                            <th>模板</th>
                            <th>模板名称</th>
                            <th>版本号</th>
                            <th>语言</th>
                            <th>作者</th>
                            <th>模板描述</th>
                            <th width="180"><?php echo lang('ACTIONS'); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(is_array($themes) || $themes instanceof \think\Collection || $themes instanceof \think\Paginator): if( count($themes)==0 ) : echo "" ;else: foreach($themes as $key=>$vo): ?>
                            <tr>
                                <td>
                                    <?php echo $vo['theme']; if($vo['theme'] == $default_theme): ?>
                                        <span class="label label-success">当前启用</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $vo['name']; ?></td>
                                <td><?php echo $vo['version']; ?></td>
                                <td><?php echo $vo['lang']; ?></td>
                                <td><?php echo $vo['author']; ?></td>
                                <td><?php echo $vo['description']; ?></td>
                                <td>
                                    <a href="javascript:parent.openIframeLayer('<?php echo url('theme/files',array('theme'=>$vo['theme'])); ?>','<?php echo $vo['name']; ?>文件列表',{});">设计</a>
                                    <a href="<?php echo url('theme/update',array('theme'=>$vo['theme'])); ?>" class="js-ajax-dialog-btn"
                                       data-msg="确定更新此模板吗？">更新</a>


                                    <?php if(($vo['name'] == 'simpleboot3') OR ($vo['theme'] == $default_theme)): ?>
                                        <font color="#cccccc">卸载</font>
                                        <?php else: ?>
                                        <a href="<?php echo url('theme/uninstall',array('theme'=>$vo['theme'])); ?>" class="js-ajax-dialog-btn"
                                           data-msg="您设置的模板数据将被删除，<br>确定卸载此模板吗？">卸载</a>
                                    <?php endif; if($vo['theme'] == $default_theme): ?>
                                        <font color="#cccccc">启用</font>
                                        <?php else: ?>
                                        <a href="<?php echo url('theme/active',array('theme'=>$vo['theme'])); ?>" class="js-ajax-dialog-btn"
                                           data-msg="确定使用此模板吗？">启用</a>
                                    <?php endif; ?>







                                </td>
                            </tr>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <th>模板</th>
                            <th>模板名称</th>
                            <th>版本号</th>
                            <th>语言</th>
                            <th>作者</th>
                            <th>模板描述</th>
                            <th width="180"><?php echo lang('ACTIONS'); ?></th>
                        </tr>
                        </tfoot>
                    </table>
                </form>
            </div>
        </div>
</div>
</div>

  </div>

  <!--   Core JS Files   -->
  <script src="/themes/admin_materialdashboard/public/assets/js/core/jquery.min.js" type="text/javascript"></script>
  <script src="/themes/admin_materialdashboard/public/assets/js/core/popper.min.js" type="text/javascript"></script>
  <script src="/themes/admin_materialdashboard/public/assets/js/core/bootstrap-material-design.min.js" type="text/javascript"></script>
  <script src="/themes/admin_materialdashboard/public/assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>

  <!-- Chartist JS -->
  <script src="/themes/admin_materialdashboard/public/assets/js/plugins/chartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="/themes/admin_materialdashboard/public/assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="/themes/admin_materialdashboard/public/assets/js/material-dashboard.min.js?v=2.1.0" type="text/javascript"></script>
  
</body>

</html>