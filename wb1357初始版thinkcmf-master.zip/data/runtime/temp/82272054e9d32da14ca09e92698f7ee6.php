<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:52:"themes/admin_materialdashboard/admin\rbac\index.html";i:1531883799;s:82:"D:\WWW\thinkcmf-master\public\themes\admin_materialdashboard\public\emptypage.html";i:1531904022;}*/ ?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="/themes/admin_materialdashboard/public/assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="/themes/admin_materialdashboard/public/assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
   
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="/themes/admin_materialdashboard/public/assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }
        .form-required {
            color: red;
        }
        .card .form-horizontal .form-group {
            margin-top: 14px;
        }
        .form-group .bmd-label-static {
          top:-20px;
        }
    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo \think\Request::instance()->module(); ?>'/*当前应用名*/
        };
    </script>
    </script>
    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>

    <script src="https://cdn.bootcss.com/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="/static/js/wind.js"></script>
    <script src="/themes/admin_materialdashboard/public/assets/js/bootstrap.min.js"></script>

    <script>
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container:'body',
                html:true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
        });

    </script>
    <?php if(APP_DEBUG): ?>
        <style>
            #think_page_trace_open {
                z-index: 9999;
            }
        </style>
    <?php endif; ?>
  
</head>

<body class="">
  <div class="content ">
    
<div class="card">
	<div class="card-header card-header-primary">

				<ul class="nav nav-tabs" data-tabs="tabs">
			<li class="nav-item">
				<a class="nav-link active" href="<?php echo url('rbac/index'); ?>"><?php echo lang('ADMIN_RBAC_INDEX'); ?></a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo url('rbac/roleAdd'); ?>"><?php echo lang('ADMIN_RBAC_ROLEADD'); ?></a>
			</li>
		</ul>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="card-body">
			
					<form action="<?php echo url('Rbac/listorders'); ?>" method="post" class="margin-top-20">
						<table class="table table-hover table-bordered">
							<thead>
								<tr>
									<th width="40">ID</th>
									<th align="left"><?php echo lang('ROLE_NAME'); ?></th>
									<th align="left"><?php echo lang('ROLE_DESCRIPTION'); ?></th>
									<th width="60" align="left"><?php echo lang('STATUS'); ?></th>
									<th width="160"><?php echo lang('ACTIONS'); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php if(is_array($roles) || $roles instanceof \think\Collection || $roles instanceof \think\Paginator): if( count($roles)==0 ) : echo "" ;else: foreach($roles as $key=>$vo): ?>
								<tr>
									<td><?php echo $vo['id']; ?></td>
									<td><?php echo $vo['name']; ?></td>
									<td><?php echo $vo['remark']; ?></td>
									<td>
										<?php if($vo['status'] == 1): ?>
											<font color="red">√</font>
										<?php else: ?> 
											<font color="red">╳</font>
										<?php endif; ?>
									</td>
									<td>
										<?php if($vo['id'] == 1): ?>
											<font color="#cccccc"><?php echo lang('ROLE_SETTING'); ?></font>  <!-- <a href="javascript:openIframeDialog('<?php echo url('rbac/member',array('id'=>$vo['id'])); ?>','成员管理');">成员管理</a> | -->
											<font color="#cccccc"><?php echo lang('EDIT'); ?></font>  <font color="#cccccc"><?php echo lang('DELETE'); ?></font>
										<?php else: ?>
											<a href="<?php echo url('Rbac/authorize',array('id'=>$vo['id'])); ?>"><?php echo lang('ROLE_SETTING'); ?></a>
											<!-- <a href="javascript:openIframeDialog('<?php echo url('rbac/member',array('id'=>$vo['id'])); ?>','成员管理');">成员管理</a>| -->
											<a href="<?php echo url('Rbac/roleedit',array('id'=>$vo['id'])); ?>"><?php echo lang('EDIT'); ?></a>
											<a class="js-ajax-delete" href="<?php echo url('Rbac/roledelete',array('id'=>$vo['id'])); ?>"><?php echo lang('DELETE'); ?></a>
										<?php endif; ?>
									</td>
								</tr>
								<?php endforeach; endif; else: echo "" ;endif; ?>
							</tbody>
						</table>
					</form>

			</div>
		</div>
	</div>

  </div>

  <!--   Core JS Files   -->
  <script src="/themes/admin_materialdashboard/public/assets/js/core/jquery.min.js" type="text/javascript"></script>
  <script src="/themes/admin_materialdashboard/public/assets/js/core/popper.min.js" type="text/javascript"></script>
  <script src="/themes/admin_materialdashboard/public/assets/js/core/bootstrap-material-design.min.js" type="text/javascript"></script>
  <script src="/themes/admin_materialdashboard/public/assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>

  <!-- Chartist JS -->
  <script src="/themes/admin_materialdashboard/public/assets/js/plugins/chartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="/themes/admin_materialdashboard/public/assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="/themes/admin_materialdashboard/public/assets/js/material-dashboard.min.js?v=2.1.0" type="text/javascript"></script>
  

	<script src="/static/js/admin.js"></script>


</body>

</html>