<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:52:"themes/admin_materialdashboard/admin\user\index.html";i:1531883799;s:82:"D:\WWW\thinkcmf-master\public\themes\admin_materialdashboard\public\emptypage.html";i:1531904022;}*/ ?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="/themes/admin_materialdashboard/public/assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="/themes/admin_materialdashboard/public/assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
   
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="/themes/admin_materialdashboard/public/assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }
        .form-required {
            color: red;
        }
        .card .form-horizontal .form-group {
            margin-top: 14px;
        }
        .form-group .bmd-label-static {
          top:-20px;
        }
    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo \think\Request::instance()->module(); ?>'/*当前应用名*/
        };
    </script>
    </script>
    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>

    <script src="https://cdn.bootcss.com/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="/static/js/wind.js"></script>
    <script src="/themes/admin_materialdashboard/public/assets/js/bootstrap.min.js"></script>

    <script>
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container:'body',
                html:true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
        });

    </script>
    <?php if(APP_DEBUG): ?>
        <style>
            #think_page_trace_open {
                z-index: 9999;
            }
        </style>
    <?php endif; ?>
  
</head>

<body class="">
  <div class="content ">
    
<div class="card">
	<div class="card-header card-header-primary">

				<ul class="nav nav-tabs" data-tabs="tabs">
			<li class="nav-item">
				<a class="nav-link active" href="<?php echo url('user/index'); ?>"><?php echo lang('ADMIN_USER_INDEX'); ?></a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo url('user/add'); ?>"><?php echo lang('ADMIN_USER_ADD'); ?></a>
			</li>
		</ul>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="card-body">
			
			        <form class="well form-inline margin-top-20" method="post" action="<?php echo url('User/index'); ?>">
			            用户名:
			            <input type="text" class="form-control" name="user_login" style="width: 120px;" value="<?php echo input('request.user_login/s',''); ?>" placeholder="请输入<?php echo lang('USERNAME'); ?>">
			            邮箱:
			            <input type="text" class="form-control" name="user_email" style="width: 120px;" value="<?php echo input('request.user_email/s',''); ?>" placeholder="请输入<?php echo lang('EMAIL'); ?>">
			            <input type="submit" class="btn btn-primary" value="搜索" />
			            <a class="btn btn-danger" href="<?php echo url('User/index'); ?>">清空</a>
			        </form>
					<div class="row">
			            <div class="col-md-12">
			              <div class="card">
			                <div class="card-header card-header-primary">
			                  <h4 class="card-title ">Simple Table</h4>
			                  <p class="card-category"> Here is a subtitle for this table</p>
			                </div>
			                <div class="card-body">
			                  <div class="table-responsive">
			                    <table class="table">
									<thead>
										<tr>
											<th width="50">ID</th>
											<th><?php echo lang('USERNAME'); ?></th>
											<th><?php echo lang('LAST_LOGIN_IP'); ?></th>
											<th><?php echo lang('LAST_LOGIN_TIME'); ?></th>
											<th><?php echo lang('EMAIL'); ?></th>
											<th><?php echo lang('STATUS'); ?></th>
											<th width="130"><?php echo lang('ACTIONS'); ?></th>
										</tr>
									</thead>
									<tbody>
										<?php $user_statuses=array("0"=>lang('USER_STATUS_BLOCKED'),"1"=>lang('USER_STATUS_ACTIVATED'),"2"=>lang('USER_STATUS_UNVERIFIED')); if(is_array($users) || $users instanceof \think\Collection || $users instanceof \think\Paginator): if( count($users)==0 ) : echo "" ;else: foreach($users as $key=>$vo): ?>
										<tr>
											<td><?php echo $vo['id']; ?></td>
											<td><?php if($vo['user_url']): ?><a href="<?php echo $vo['user_url']; ?>" target="_blank" title="<?php echo $vo['signature']; ?>"><?php echo $vo['user_login']; ?></a><?php else: ?><?php echo $vo['user_login']; endif; ?></td>
											<td><?php echo $vo['last_login_ip']; ?></td>
											<td>
												<?php if($vo['last_login_time'] == 0): ?>
													<?php echo lang('USER_HAVE_NOT_LOGIN'); else: ?>
													<?php echo date('Y-m-d H:i:s',$vo['last_login_time']); endif; ?>
											</td>
											<td><?php echo $vo['user_email']; ?></td>
											<td><?php echo $user_statuses[$vo['user_status']]; ?></td>
											<td>
												<?php if($vo['id'] == 1 || $vo['id'] == cmf_get_current_admin_id()): ?>
												<font color="#cccccc"><?php echo lang('EDIT'); ?></font>  <font color="#cccccc"><?php echo lang('DELETE'); ?></font>
													<?php if($vo['user_status'] == 1): ?>
														<font color="#cccccc"><?php echo lang('BLOCK_USER'); ?></font>
													<?php else: ?>
														<font color="#cccccc"><?php echo lang('ACTIVATE_USER'); ?></font>
													<?php endif; else: ?>
													<a href='<?php echo url("user/edit",array("id"=>$vo["id"])); ?>'><?php echo lang('EDIT'); ?></a>
													<a class="js-ajax-delete" href="<?php echo url('user/delete',array('id'=>$vo['id'])); ?>"><?php echo lang('DELETE'); ?></a>
													<?php if($vo['user_status'] == 1): ?>
														<a href="<?php echo url('user/ban',array('id'=>$vo['id'])); ?>" class="js-ajax-dialog-btn" data-msg="<?php echo lang('BLOCK_USER_CONFIRM_MESSAGE'); ?>"><?php echo lang('BLOCK_USER'); ?></a>
													<?php else: ?>
														<a href="<?php echo url('user/cancelban',array('id'=>$vo['id'])); ?>" class="js-ajax-dialog-btn" data-msg="<?php echo lang('ACTIVATE_USER_CONFIRM_MESSAGE'); ?>"><?php echo lang('ACTIVATE_USER'); ?></a>
													<?php endif; endif; ?>
											</td>
										</tr>
										<?php endforeach; endif; else: echo "" ;endif; ?>
									</tbody>
								</table>
								</div>
							</div>
						  </div>
						</div>
					</div>
					<div class="pagination"><?php echo $page; ?></div>

			</div>
		</div>
	</div>

  </div>

  <!--   Core JS Files   -->
  <script src="/themes/admin_materialdashboard/public/assets/js/core/jquery.min.js" type="text/javascript"></script>
  <script src="/themes/admin_materialdashboard/public/assets/js/core/popper.min.js" type="text/javascript"></script>
  <script src="/themes/admin_materialdashboard/public/assets/js/core/bootstrap-material-design.min.js" type="text/javascript"></script>
  <script src="/themes/admin_materialdashboard/public/assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>

  <!-- Chartist JS -->
  <script src="/themes/admin_materialdashboard/public/assets/js/plugins/chartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="/themes/admin_materialdashboard/public/assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="/themes/admin_materialdashboard/public/assets/js/material-dashboard.min.js?v=2.1.0" type="text/javascript"></script>
  

	<script src="/static/js/admin.js"></script>


</body>

</html>