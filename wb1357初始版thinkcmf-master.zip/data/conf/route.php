<?php	return array (
  '世界上最好的语言-php/:id' => 
  array (
    0 => 'portal/Article/index?cid=1',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  '通用的胶水语言-python/:id' => 
  array (
    0 => 'portal/Article/index?cid=2',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  '浏览器喜欢的方式-html+css+javascript/:id' => 
  array (
    0 => 'portal/Article/index?cid=3',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  'technology/:id' => 
  array (
    0 => 'portal/Article/index?cid=4',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  'current-news/:id' => 
  array (
    0 => 'portal/Article/index?cid=5',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  'course/:id' => 
  array (
    0 => 'portal/Article/index?cid=6',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  'scratch/:id' => 
  array (
    0 => 'portal/Article/index?cid=7',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  'knowledge/:id' => 
  array (
    0 => 'portal/Article/index?cid=8',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  'friends/:id' => 
  array (
    0 => 'portal/Article/index?cid=9',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  'Raspberry Pi/:id' => 
  array (
    0 => 'portal/Article/index?cid=10',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  '世界上最好的语言-php' => 
  array (
    0 => 'portal/List/index?id=1',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  '通用的胶水语言-python' => 
  array (
    0 => 'portal/List/index?id=2',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  '浏览器喜欢的方式-html+css+javascript' => 
  array (
    0 => 'portal/List/index?id=3',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  'technology' => 
  array (
    0 => 'portal/List/index?id=4',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  'current-news' => 
  array (
    0 => 'portal/List/index?id=5',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  'course' => 
  array (
    0 => 'portal/List/index?id=6',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  'scratch' => 
  array (
    0 => 'portal/List/index?id=7',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  'knowledge' => 
  array (
    0 => 'portal/List/index?id=8',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  'friends' => 
  array (
    0 => 'portal/List/index?id=9',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  'Raspberry Pi' => 
  array (
    0 => 'portal/List/index?id=10',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
);