/**
 * Custom Helper
 * wanglelecc
 * https://github.com/wanglelecc/assets
 */
class helper{

    static test(){
        console.log('test...');
        
        return 'test';
    }

}

module.exports = helper;