<?php
//000000000000
 exit();?>
s:89:"D:\WWW\thinkcmf-master\public/../data/runtime/cache\c3\0b008a754ac7f1eeef085057ee3106.php";