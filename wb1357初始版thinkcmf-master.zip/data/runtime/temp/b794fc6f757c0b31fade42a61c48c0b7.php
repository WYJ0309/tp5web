<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:32:"themes/samples/sample\\mail.html";i:1543480815;s:61:"D:\WWW\thinkcmf-master\public\themes\samples\public\head.html";i:1543480540;s:63:"D:\WWW\thinkcmf-master\public\themes\samples\public\footer.html";i:1543480735;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link href="/themes/samples/css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link href="/themes/samples/css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <!-- web-font -->
    <!--<link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playball' rel='stylesheet' type='text/css'>-->
    <!-- web-font -->
    <!-- js -->
    <script src="/themes/samples/js/jquery.min.js"></script>
    <script src="/themes/samples/js/modernizr.custom.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!-- js -->
    <script src="/themes/samples/js/modernizr.custom.js"></script>
    <!-- start-smoth-scrolling -->
    <script type="text/javascript" src="/themes/samples/js/move-top.js"></script>
    <script type="text/javascript" src="/themes/samples/js/easing.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".scroll").click(function(event){
                event.preventDefault();
                $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
            });
        });
    </script>
    <!-- start-smoth-scrolling -->
</head>
	<body>
		<div class="head-bg green">
			<!-- container -->
			<div class="container">
				<div class="head-logo">
					<a href="index.html"><img src="/themes/samples/images/logo1.png" alt="" /></a>
				</div>
				<div class="top-nav">
						<span class="menu"><img src="/themes/samples/images/menu.png" alt=""></span>
							<ul class="cl-effect-1">
								<li><a href="index.html">HOME</a></li>                                             
								<li><a href="about.html">ABOUT</a></li>
								<li><a href="booking.html">BOOKING</a></li> 
								<li><a href="news.html">NEWS</a></li> 
								<li><a href="mail.html">MAIL US</a></li>  
							</ul>
							<!-- script-for-menu -->
							 <script>
							   $( "span.menu" ).click(function() {
								 $( "ul.cl-effect-1" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
						<!-- /script-for-menu -->
					</div>
				<div class="clearfix"> </div>
			</div>
			<!-- //container -->
		</div>
		<!-- mail -->
		<div class="mail">
			<!-- container -->
			<div class="container">
				<div class="mail-info">
					<h3>OUR LOCATION</h3>
				</div>
				<div class="map">
					<iframe src=""></iframe>
				</div>
				<div class="mail-info-grids">
					<div class="col-md-6 mail-info-grid">
						<h3>Contact Information</h3>
						<p>In pharetra dui vitae odio maximus vulputate. Nul
							am finibus dui more neque dui vitae odio maximu.
							In pharetra dui vitae odio maximus vulputate. Null
							finibus dui more neque.odio maximus vulputate. 
							Nulla odio maximus vulputate. Nulla odio maxi.
						</p>
						<h6>The Company Name agi.
						<span>756 gt globel Place,</span>
							CD-Road,M 07 435.
						</h6>
						<p>Telephone: +1 234 567 9871
						<span>FAX: +1 234 567 9871</span>
						E-mail: <a href="mailto:info@example.com">mail@example.com</a>
						</p>
					</div>
					<div class="col-md-6 contact-form">
						<form>
							<input type="text" placeholder="Name:" required="">
							<input type="text" placeholder="Email:" required="">
							<input type="text" placeholder="Subject:" required="">
							<textarea placeholder="Message:" required=""></textarea>
							<input type="submit" value="SEND">
						</form>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
			<!-- //container -->
		</div>
		<!-- //mail -->
		<!-- footer -->
		<div class="footer">
    <!-- container -->
    <div class="container">
        <div class="footer-left">
            <p>Copyright &copy; 2014.Company name All rights reserved.More Templates <a href="" target="_blank" title="模板之家">模板之家</a> - Collect from <a href="" title="网页模板" target="_blank">网页模板</a></p>
        </div>
        <div class="footer-right">
            <div class="footer-nav">
                <ul>
                    <li><a href="/">HOME</a></li>
                    <li><a href="<?php echo cmf_url('sample/Index/about'); ?>">ABOUT</a></li>
                    <li><a href="<?php echo cmf_url('sample/Index/booking'); ?>">BOOKING</a></li>
                    <li><a href="<?php echo cmf_url('sample/Index/news'); ?>">NEWS</a></li>
                    <li><a href="<?php echo cmf_url('sample/Index/mail'); ?>">MAIL US</a></li>
                </ul>
            </div>
        </div>
        <div class="clearfix"> </div>
    </div>
    <!-- //container -->
</div>
<script type="text/javascript">
    $(document).ready(function() {
        /*
         var defaults = {
         containerID: 'toTop', // fading element id
         containerHoverID: 'toTopHover', // fading element hover id
         scrollSpeed: 1200,
         easingType: 'linear'
         };
         */

        $().UItoTop({ easingType: 'easeOutQuart' });

    });
</script>
<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
		<!-- //footer -->
	<!-- content-Get-in-touch -->
	
</body>
</html>