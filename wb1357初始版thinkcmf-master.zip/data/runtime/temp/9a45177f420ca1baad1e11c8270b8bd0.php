<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:53:"themes/admin_materialdashboard/admin\index\index.html";i:1531968247;s:86:"D:\WWW\thinkcmf-master\public\themes\admin_materialdashboard\public\frametemplate.html";i:1531905265;}*/ ?>

 <?php $submenus=$menus; function getsubmenu($submenus){ if(!(empty($submenus) || (($submenus instanceof \think\Collection || $submenus instanceof \think\Paginator ) && $submenus->isEmpty()))): foreach($submenus as $menu){ ?>
            <li class="nav-item">
                <?php 
                    $menu_name=lang($menu['lang']);
                    $menu_name=$menu['lang']==$menu_name?$menu['name']:$menu_name;
                 if(empty($menu['items'])){ ?>

                    <a href="javascript:openapp('<?php echo $menu['url']; ?>','<?php echo $menu['id']; ?>','<?php echo $menu_name; ?>',true);" class="nav-link">
                        <i class="material-icons">library_books</i>
                        <span class="menu-text"> <?php echo $menu_name; ?> </span>
                    </a>
                <?php }else{ ?>

                    <a href="#" class="nav-link dropdown-toggle">
                        <i class="material-icons">library_books</i>
                        <span class="menu-text normal"> <?php echo $menu_name; ?> </span>
                    </a>

                    <ul class="submenu">
                        <?php getsubmenu1($menu['items']) ?>
                    </ul>
                <?php } ?>

            </li>

        <?php } endif; } function getsubmenu1($submenus){ foreach($submenus as $menu){ ?>
    <li>
        <?php 
            $menu_name=lang($menu['lang']);
            $menu_name=$menu['lang']==$menu_name?$menu['name']:$menu_name;
         if(empty($menu['items'])){ ?>
        <a href="javascript:openapp('<?php echo $menu['url']; ?>','<?php echo $menu['id']; ?>','<?php echo $menu_name; ?>',true);" class="nav-link">
            <i class="fa fa-caret-right"></i>
            <span class="menu-text">
                                    <?php echo $menu_name; ?>
                                </span>
        </a>
        <?php }else{ ?>

        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
            <i class="fa fa-caret-right"></i>
            <span class="menu-text">
                                    <?php echo $menu_name; ?>
                                </span>
            <b class="arrow fa fa-angle-right"></b>
        </a>
        <ul class="submenu">
            <?php getsubmenu2($menu['items']) ?>
        </ul>
        <?php } ?>

    </li>

    <?php } } function getsubmenu2($submenus){ foreach($submenus as $menu){ ?>
    <li>
        <?php 
            $menu_name=lang($menu['lang']);
            $menu_name=$menu['lang']==$menu_name?$menu['name']:$menu_name;
         ?>

        <a href="javascript:openapp('<?php echo $menu['url']; ?>','<?php echo $menu['id']; ?>','<?php echo $menu_name; ?>',true);" class="nav-link">
            &nbsp;<i class="fa fa-angle-double-right"></i>
            <span class="menu-text">
                                <?php echo $menu_name; ?>
                            </span>
        </a>
    </li>

    <?php } } ?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="/themes/admin_materialdashboard/public/assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="/themes/admin_materialdashboard/public/assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
   
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="/themes/admin_materialdashboard/public/assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
        }
    .coverbg{
      color: #3C4858;
    }
    .coverbgbg:after{
      position: absolute;
      z-index: 3;
      width: 100%;
      content: "";
      display: block;
      background: #FFFFFF;
      opacity: .93;   
      height: 71px;   
    }


    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo \think\Request::instance()->module(); ?>'/*当前应用名*/
        };
    </script>
    

  
        <style>
        .nav-list li{
            padding: 0;
            margin: 0;
            list-style: none;
        }
        .nav-list .submenu{
            padding: 0.5em;
        }
        
        .submenu{
            display: none;
        }
        .cmf-component-tabitem{
            position: relative;

            display: inline-block !important;
            float: none !important;
            min-width: 101px;
            text-align: center;
            cursor: pointer;
            vertical-align: top;
        }
        .cmf-component-tab {
            white-space: nowrap;
            float: left;
            margin: 0;
            display: inline-block !important;
        }
        #task-content{
                position: relative;
            float: left;
            overflow: hidden;
        }



        /*----------------导航hack--------------------*/
    </style>

    <script>
        //全局变量
        var GV = {
            HOST: "<?php echo $_SERVER['HTTP_HOST']; ?>",
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/"
        };
    </script>

</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="white" data-image="/themes/admin_materialdashboard/public/assets/img/sidebar-1.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-normal">
          ThinkCMF
        </a>
      </div>
      <div class="sidebar-wrapper">
        
    <div class="sidebar-shortcuts" id="sidebar-shortcuts">


            <?php if(cmf_auth_check(cmf_get_current_admin_id(),'user/AdminAsset/index')): ?>
                <a class="btn btn-sm btn-info"
                   href="javascript:openapp('<?php echo url('user/AdminAsset/index'); ?>','userAdminAssetindex','资源管理',true);"
                   title="资源管理"
                   data-toggle="tooltip">
                    <i class="fa fa-file"></i>
                </a>
            <?php endif; if(cmf_auth_check(cmf_get_current_admin_id(),'admin/Setting/clearcache')): ?>
                <a class="btn btn-sm btn-danger"
                   href="javascript:openapp('<?php echo url('admin/Setting/clearcache'); ?>','index_clearcache','<?php echo lang('ADMIN_SETTING_CLEARCACHE'); ?>',true);"
                   title="<?php echo lang('ADMIN_SETTING_CLEARCACHE'); ?>"
                   data-toggle="tooltip">
                    <i class="fa fa-trash-o"></i>
                </a>
            <?php endif; if(cmf_auth_check(cmf_get_current_admin_id(),'admin/RecycleBin/index')): ?>
                <a class="btn btn-sm btn-danger"
                   href="javascript:openapp('<?php echo url('admin/RecycleBin/index'); ?>','index_recycle','回收站',true);"
                   title="回收站"
                   data-toggle="tooltip">
                    <i class="fa fa-recycle"></i>
                </a>
            <?php endif; if(APP_DEBUG): ?>
                <a class="btn btn-sm btn-default"
                   href="javascript:openapp('<?php echo url('admin/Menu/index'); ?>','index_menu','<?php echo lang('ADMIN_MENU_INDEX'); ?>',true);"
                   title="<?php echo lang('ADMIN_MENU_INDEX'); ?>"
                   data-toggle="tooltip">
                    <i class="fa fa-list"></i>
                </a>
            <?php endif; ?>

        </div>    

        <ul class="nav nav-list collapse in" id="sidebar">
          
    <?php echo getsubmenu($submenus); ?>


          <li class="nav-item">
            <a href="#" class="nav-link dropdown-toggle">
                <i class="material-icons">library_books</i>
                <span class="menu-text normal"> demo </span>
            </a>
            <ul class="submenu">
                <li>
                  <a href="javascript:openapp('/user/Admin_demo/table.html','1111table','表格列表',true);" class="nav-link">
                    <i class="fa fa-caret-right"></i>
                    <span class="menu-text">表格列表</span>
                  </a>
                </li>
                <li>
                  <a href="javascript:openapp('/user/Admin_demo/chart.html','1111chart','图表',true);" class="nav-link">
                    <i class="fa fa-caret-right"></i>
                    <span class="menu-text">图表</span>
                  </a>
                </li>
                <li>
                  <a href="javascript:openapp('/user/Admin_demo/form.html','1111form','表单',true);" class="nav-link">
                    <i class="fa fa-caret-right"></i>
                    <span class="menu-text">表单</span>
                  </a>
                </li>
            </ul>
                          
          </li>

          <!-- your sidebar here -->
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top  coverbg"  data-image="/themes/admin_materialdashboard/public/assets/img/sidebar-1.jpg">
          <div id="task-content" >
              <ul class="nav navbar-nav cmf-component-tab" id="task-content-inner">
                  <li class="cmf-component-tabitem noclose" app-id="0" app-url="/admin/main/index.html" app-name="首页">
                      <a class="navbar-brand"><?php echo lang('HOME'); ?><div class="ripple-container"></div></a>
                  </li>
              </ul>
              <div style="clear:both;"></div>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="navbar-collapse collapse" id="navbar-main">

            <div class="collapse navbar-collapse justify-content-end">
              <ul class="navbar-nav">
                  <li class="nav-item light-blue dropdown" style="border-left:none;">
                      <a data-toggle="dropdown" href="#" class="dropdown-toggle">
                          <?php if(isset($admin['avatar']) && $admin['avatar']): ?>
                              <img class="nav-user-photo" width="30" height="30"
                                   src="<?php echo cmf_get_user_avatar_url($admin['avatar']); ?>" alt="<?php echo $admin['user_login']; ?>">
                              <?php else: ?>
                              <img class="nav-user-photo" width="30" height="30"
                                   src="/themes/admin_materialdashboard/public/assets/images/logo-18.png" alt="<?php echo (isset($admin['user_login']) && ($admin['user_login'] !== '')?$admin['user_login']:''); ?>">
                          <?php endif; ?>
                          <span class="user-info">
                                  <?php echo lang('WELCOME_USER',array('user_nickname' => empty($admin['user_nickname'] )? $admin['user_login'] : $admin['user_nickname'])); ?>
                              </span>
                      </a>
                      <ul class="user-menu pull-right dropdown-menu dropdown-yellow dropdown-caret dropdown-closer">
                          <?php if(cmf_auth_check(cmf_get_current_admin_id(),'admin/Setting/site')): ?>
                              <li>
                                  <a href="javascript:openapp('<?php echo url('setting/site'); ?>','index_site','<?php echo lang('ADMIN_SETTING_SITE'); ?>');"><i
                                          class="fa fa-cog"></i> <?php echo lang('ADMIN_SETTING_SITE'); ?></a></li>
                          <?php endif; if(cmf_auth_check(cmf_get_current_admin_id(),'admin/user/userinfo')): ?>
                              <li>
                                  <a href="javascript:openapp('<?php echo url('user/userinfo'); ?>','index_userinfo','<?php echo lang('ADMIN_USER_USERINFO'); ?>');"><i
                                          class="fa fa-user"></i> <?php echo lang('ADMIN_USER_USERINFO'); ?></a></li>
                          <?php endif; if(cmf_auth_check(cmf_get_current_admin_id(),'admin/Setting/password')): ?>
                              <li>
                                  <a href="javascript:openapp('<?php echo url('setting/password'); ?>','index_password','<?php echo lang('ADMIN_SETTING_PASSWORD'); ?>');"><i
                                          class="fa fa-lock"></i> <?php echo lang('ADMIN_SETTING_PASSWORD'); ?></a></li>
                          <?php endif; ?>
                          <li><a href="<?php echo url('Public/logout'); ?>"><i class="fa fa-sign-out"></i> <?php echo lang('LOGOUT'); ?></a></li>
                      </ul>
                  </li>
              </ul>
            </div>
          </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <!-- your content here -->
          
    <div class="page-content" id="content">
        <iframe src="<?php echo url('Main/index'); ?>" style="width:100%;height: 100%;" frameborder="0" id="appiframe-0"
                    class="appiframe"></iframe>
    </div>

        </div>
      </div>

    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="/themes/admin_materialdashboard/public/assets/js/core/jquery.min.js" type="text/javascript"></script>
  <script src="/themes/admin_materialdashboard/public/assets/js/core/popper.min.js" type="text/javascript"></script>
  <script src="/themes/admin_materialdashboard/public/assets/js/core/bootstrap-material-design.min.js" type="text/javascript"></script>
  <script src="/themes/admin_materialdashboard/public/assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>

  <!-- Chartist JS -->
  <script src="/themes/admin_materialdashboard/public/assets/js/plugins/chartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="/themes/admin_materialdashboard/public/assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="/themes/admin_materialdashboard/public/assets/js/material-dashboard.min.js?v=2.1.0" type="text/javascript"></script>
<script src="/static/js/wind.js"></script>


    <script>
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container:'body',
                html:true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
        });

    </script>
  <script type="text/javascript">
    $('.coverbg').each(function(i,v){
      var img = $(v).attr('data-image');
      $(v).after('<div class="coverbgbg" style="background-image: url('+img+')"></div>');
    })
  </script>
  
<script src="/static/js/admin.js"></script>
<script src="/themes/admin_materialdashboard/public/assets/js/adminindex.js"></script>
<script>
    $(function () {
        $("[data-toggle='tooltip']").tooltip();
        $("li.dropdown").hover(function () {
            $(this).addClass("open");
        }, function () {
            $(this).removeClass("open");
        });

        var menus= <?php echo $menus_js_var; ?>;
        //读取url参数。尝试执行菜单功能。
        if(typeof(menus) != "undefined"){

            var tw = window.top;
            var twa =tw.location.href.split("#");
            var url = twa[1];
            var urlTmp = url;
            if (url !=null ){
                //去掉/ 去掉_ 全部小写。
                urlTmp = urlTmp.replace(/[\\/|_|]/g,"");
                urlTmp = urlTmp.replace(".html","");
                var menu = menus[urlTmp];
                if (menu){
                    openapp(url,menu.id+menu.app,menu.name,true);
                }
            }
        }




    });

    var ismenumin = $("#sidebar").hasClass("menu-min");
    $(".nav-list").on("click", function (event) {
        var closest_a = $(event.target).closest("a");
        if (!closest_a || closest_a.length == 0) {
            return
        }
        if (!closest_a.hasClass("dropdown-toggle")) {
            if (ismenumin && "click" == "tap" && closest_a.get(0).parentNode.parentNode == this) {
                var closest_a_menu_text = closest_a.find(".menu-text").get(0);
                if (event.target != closest_a_menu_text && !$.contains(closest_a_menu_text, event.target)) {
                    return false
                }
            }
            return
        }
        var closest_a_next = closest_a.next().get(0);
        if (!$(closest_a_next).is(":visible")) {
            var closest_ul = $(closest_a_next.parentNode).closest("ul");
            if (ismenumin && closest_ul.hasClass("nav-list")) {
                return
            }
            closest_ul.find("> .open > .submenu").each(function () {
                if (this != closest_a_next && !$(this.parentNode).hasClass("active")) {
                    $(this).slideUp(150).parent().removeClass("open")
                }
            });
        }
        if (ismenumin && $(closest_a_next.parentNode.parentNode).hasClass("nav-list")) {
            return false;
        }
        $(closest_a_next).slideToggle(150).parent().toggleClass("open");
        return false;
    });



</script>


</body>

</html>