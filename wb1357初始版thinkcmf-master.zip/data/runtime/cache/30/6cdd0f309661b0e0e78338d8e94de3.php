<?php
//000000000000
 exit();?>
a:8:{s:9:"site_name";s:27:"会飞的砖，挨揍的鱼";s:14:"site_seo_title";s:27:"会飞的砖，挨揍的鱼";s:17:"site_seo_keywords";s:27:"会飞的砖，挨揍的鱼";s:20:"site_seo_description";s:27:"会飞的砖，挨揍的鱼";s:8:"site_icp";s:0:"";s:8:"site_gwa";s:0:"";s:16:"site_admin_email";s:17:"3116373546@qq.com";s:14:"site_analytics";s:0:"";}