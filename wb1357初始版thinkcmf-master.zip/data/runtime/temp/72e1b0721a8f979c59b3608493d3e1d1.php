<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:33:"themes/samples/sample\\index.html";i:1543480731;s:61:"D:\WWW\thinkcmf-master\public\themes\samples\public\head.html";i:1543480540;s:63:"D:\WWW\thinkcmf-master\public\themes\samples\public\footer.html";i:1543480735;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link href="/themes/samples/css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link href="/themes/samples/css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <!-- web-font -->
    <!--<link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playball' rel='stylesheet' type='text/css'>-->
    <!-- web-font -->
    <!-- js -->
    <script src="/themes/samples/js/jquery.min.js"></script>
    <script src="/themes/samples/js/modernizr.custom.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!-- js -->
    <script src="/themes/samples/js/modernizr.custom.js"></script>
    <!-- start-smoth-scrolling -->
    <script type="text/javascript" src="/themes/samples/js/move-top.js"></script>
    <script type="text/javascript" src="/themes/samples/js/easing.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".scroll").click(function(event){
                event.preventDefault();
                $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
            });
        });
    </script>
    <!-- start-smoth-scrolling -->
</head>
	<body>
		<!-- header -->
		<div class="header">
			<div class="head-bg">
				<!-- container -->
				<div class="container">
					<div class="head-logo">
						<a href="index.html"><img src="/themes/samples/images/logo1.png" alt="" /></a>
					</div>
					<div class="top-nav">
						<span class="menu"><img src="/themes/samples/images/menu.png" alt=""></span>
							<ul class="cl-effect-1">
								<li><a href="/">HOME</a></li>
								<li><a href="<?php echo cmf_url('sample/Index/about'); ?>">ABOUT</a></li>
								<li><a href="<?php echo cmf_url('sample/Index/booking'); ?>">BOOKING</a></li>
								<li><a href="<?php echo cmf_url('sample/Index/news'); ?>">NEWS</a></li>
								<li><a href="<?php echo cmf_url('sample/Index/mail'); ?>">MAIL US</a></li>
							</ul>
							<!-- script-for-menu -->
							 <script>
							   $( "span.menu" ).click(function() {
								 $( "ul.cl-effect-1" ).slideToggle( 300, function() {
								 // Animation complete.
								  });
								 });
							</script>
						<!-- /script-for-menu -->
					</div>
					<div class="clearfix"> </div>
				</div>
				<!-- //container -->
			</div>
			<!-- container -->
			<div class="container">
					<div  id="top" class="callbacks_container">
						<ul class="rslides" id="slider3">
							<li>
								<div class="head-info">
									<h1> Duis purus leo<span>faucibus eu semper ut, hendrerit</span></h1>
									<p>Sollicitudin et elit sit amet, luctus placerat ipsum</p>
								</div>
							</li>
							<li>
								<div class="head-info">
									<h1>Aenean suscipit<span>Suspendisse venenatis volutpat </span></h1>
									<p>Morbi id felis porttitor tellus viverra pulvinar. Vestibulum </p>
								</div>
							</li>
							<li>
								<div class="head-info">
									<h1>Gestas vulputate<span>Morbi id felis porttitor tellus</span></h1>
									<p>Morbi id felis porttitor tellus viverra pulvinar.ante ipsum </p>
								</div>
							</li>
						</ul>
					</div>

			</div>
			<!-- container -->
		</div>
		<!-- //header -->
		<!-- banner-grids -->
		<div class="banner-grids">
			<!-- container -->
			<div class="container">
				<div class="banner-grid-info">
					<h3>TOP DESTINATIONS</h3>
					<p>Pellentesque tempor sem in scelerisque mollis.</p>
				</div>
				<div class="top-grids">
					<div class="top-grid">
						<img src="images/6.jpg" alt="" />
						<div class="top-grid-info">
							<h3>Vestibulum auctor</h3>
							<p>Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices .</p>
						</div>
					</div>
					<div class="top-grid">
						<img src="images/3.jpg" alt="" />
						<div class="top-grid-info">
							<h3>Vestibulum auctor</h3>
							<p>Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices .</p>
						</div>
					</div>
					<div class="top-grid">
						<img src="images/2.jpg" alt="" />
						<div class="top-grid-info">
							<h3>Vestibulum auctor</h3>
							<p>Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices .</p>
						</div>
					</div>
					<div class="top-grid">
						<img src="images/4.jpg" alt="" />
						<div class="top-grid-info">
							<h3>Vestibulum auctor</h3>
							<p>Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices .</p>
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
			<!-- //container -->
		</div>
		<!-- //banner-grids -->
		<div class="tlinks">Collect from <a href="" >手机网站模板</a></div>
		<!-- before -->
		<div class="before">
			<!-- container -->
			<div class="container">
				<h2>Before you leave</h2>
				<div class="before-grids">
					<div class="before-grid">
						<h3>visa & documents</h3>
						<p>Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.
							Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.
						</p>
					</div>
					<div class="before-grid">
						<h3>visa & documents</h3>
						<p>Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.
							Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.
						</p>
					</div>
					<div class="before-grid">
						<h3>visa & documents</h3>
						<p>Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.
							Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.
						</p>
					</div>
					<div class="clearfix"> </div>
					<div class="search">
						<p>get hottest deals to your inbox</p>
						<form>
							<input type="text" placeholder="Email address" required="">
							<input type="submit" value="Subscribe">
						</form>
					</div>
				</div>
			</div>
			<!-- //container -->
		</div>
		<!-- //before -->
		<!-- footer -->
		<div class="footer">
    <!-- container -->
    <div class="container">
        <div class="footer-left">
            <p>Copyright &copy; 2014.Company name All rights reserved.More Templates <a href="" target="_blank" title="模板之家">模板之家</a> - Collect from <a href="" title="网页模板" target="_blank">网页模板</a></p>
        </div>
        <div class="footer-right">
            <div class="footer-nav">
                <ul>
                    <li><a href="/">HOME</a></li>
                    <li><a href="<?php echo cmf_url('sample/Index/about'); ?>">ABOUT</a></li>
                    <li><a href="<?php echo cmf_url('sample/Index/booking'); ?>">BOOKING</a></li>
                    <li><a href="<?php echo cmf_url('sample/Index/news'); ?>">NEWS</a></li>
                    <li><a href="<?php echo cmf_url('sample/Index/mail'); ?>">MAIL US</a></li>
                </ul>
            </div>
        </div>
        <div class="clearfix"> </div>
    </div>
    <!-- //container -->
</div>
<script type="text/javascript">
    $(document).ready(function() {
        /*
         var defaults = {
         containerID: 'toTop', // fading element id
         containerHoverID: 'toTopHover', // fading element hover id
         scrollSpeed: 1200,
         easingType: 'linear'
         };
         */

        $().UItoTop({ easingType: 'easeOutQuart' });

    });
</script>
<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
		<!-- //footer -->
		<!-- banner Slider starts Here -->
		<script src="/themes/samples/js/responsiveslides.min.js"></script>
		<script>
			// You can also use "$(window).load(function() {"
			$(function () {
				// Slideshow 4
				$("#slider3").responsiveSlides({
					auto: true,
					pager: false,
					nav: false,
					speed: 500,
					namespace: "callbacks",
					before: function () {
						$('.events').append("<li>before event fired.</li>");
					},
					after: function () {
						$('.events').append("<li>after event fired.</li>");
					}
				});

			});
		</script>
		<!--//End-slider-script -->
	<!-- content-Get-in-touch -->
	
</body>
</html>